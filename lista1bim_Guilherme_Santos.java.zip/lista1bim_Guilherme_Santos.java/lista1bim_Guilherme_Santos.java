import java.util.Scanner;
import java.util.Random;

public class lista1bim_Guilherme_Santos {

    static Scanner s = new Scanner(System.in);

    public static void main(String[] args) {

        int Opcao;

        do {
            System.out.println("\n===== LISTA 1º BIMESTRE - UNIPAR =====");
            System.out.println("1 - Comparar dois números");
            System.out.println("2 - Verificar Par ou Ímpar");
            System.out.println("3 - Consumo de água");
            System.out.println("4 - Potência ou Raiz");
            System.out.println("5 - Tipo de triângulo");
            System.out.println("6 - Peso ideal");
            System.out.println("7 - Idade para votar/habilitação");
            System.out.println("8 - Categoria do nadador");
            System.out.println("9 - Soma de números pares");
            System.out.println("10 - Jogo de adivinhação");
            System.out.println("11 - Sorteio entre 10 e 29");
            System.out.println("12 - Ordenar três números");
            System.out.println("13 - Contar vogais e consoantes");
            System.out.println("14 - Validador de senha");
            System.out.println("15 - Função cálculo");
            System.out.println("0 - Sair");
            System.out.print("Escolha o exercício: ");
            Opcao = s.nextInt();

            switch (Opcao) {
    case 1:
        exercicio1();
        break;
    case 2:
        exercicio2();
        break;
    case 3:
        exercicio3();
        break;
    case 4:
        exercicio4();
        break;
    case 5:
        exercicio5();
        break;
    case 6:
        exercicio6();
        break;
    case 7:
        exercicio7();
        break;
    case 8:
        exercicio8();
        break;
    case 9:
        exercicio9();
        break;
    case 10:
        exercicio10();
        break;
    case 11:
        exercicio11();
        break;
    case 12:
        exercicio12();
        break;
    case 13:
        exercicio13();
        break;
    case 14:
        exercicio14();
        break;
    case 15:
        exercicio15();
        break;
    case 0:
        System.out.println("Encerrando o programa...");
        break;
    default:
        System.out.println("Opção inválida!");
        break;
}

        } while (Opcao != 0);
    }

    static void exercicio1() {
        System.out.print("Digite o primeiro número: ");
        int a = s.nextInt();
        System.out.print("Digite o segundo número: ");
        int b = s.nextInt();

        if (a > b)
            System.out.println("O primeiro número é maior.");
        else if (a < b)
            System.out.println("O segundo número é maior.");
        else
            System.out.println("Os dois são iguais.");
    }

    static void exercicio2() {
        System.out.print("Digite um número: ");
        int n = s.nextInt();

        if (n % 2 == 0)
            System.out.println("O número é par.");
        else
            System.out.println("O número é ímpar.");
    }

    static void exercicio3() {
        System.out.print("Leitura do Relógio de Água, Dia 1: ");
        double Inicio = s.nextDouble();
        System.out.print("Leitura do Relógio de Água, Dia 30: ");
        double Fim = s.nextDouble();

        double Consumo = Fim - Inicio;
        double Media = Consumo / 30;

        System.out.println("Consumo total: " + Consumo + " Litros");
        System.out.println("Média por dia: " + Media + " Litros");
    }

    static void exercicio4() {
        System.out.print("Digite um número: ");
        int n = s.nextInt();

        if (n > 10 && n < 100)
            System.out.println("Potência: " + (n * n));
        else
            System.out.println("Raiz Quadrada: " + Math.sqrt(n));
    }

    static void exercicio5() {
        int LadoA, LadoB, LadoC;
        String msg = "";
        System.out.println("Algoritmo para calcular o tipo de um triângulo.");
        System.out.print("Informe o primeiro lado: ");
        LadoA = s.nextInt();
        System.out.print("Informe o segundo lado: ");
        LadoB = s.nextInt();
        System.out.print("Informe o terceiro lado: ");
        LadoC = s.nextInt();
        
        if (LadoA < LadoB+LadoC && LadoB < LadoA+LadoC && LadoC < LadoA+LadoB) {
            if (LadoA == LadoB && LadoB == LadoC) {
                msg = "É um triângulo Equilátero";
            }else if (LadoA != LadoB && LadoB != LadoC) {
                msg = "É um triângulo Escaleno!";
            }else{
                msg = "É um triângulo Isóceles!";
            }
        }else{
            msg = "Não é um Triângulo!";
        }

        System.out.println("Resultado: " + msg);
}

    static void exercicio6() {
        System.out.print("Altura: ");
        double a = s.nextDouble();
        System.out.print("Peso atual: ");
        double p = s.nextDouble();
        System.out.print("Gênero (M/F): ");
        char g = s.next().toUpperCase().charAt(0);

        double Ideal = 0;
        if (g == 'M')
            Ideal = (72.7 * a) - 58;
        else if (g == 'F')
            Ideal = (62.1 * a) - 44.7;

        System.out.println("Peso ideal: " + Ideal);

        if (p < Ideal)
            System.out.println("Abaixo do peso ideal.");
        else if (p > Ideal)
            System.out.println("Acima do peso ideal.");
        else
            System.out.println("No peso ideal.");
    }

    static void exercicio7() {
        System.out.print("Ano de nascimento: ");
        int AnoNascimento = s.nextInt();

        System.out.print("Ano atual: ");
        int AnoAtual = s.nextInt();

        int Idade = AnoAtual - AnoNascimento;

        if (Idade >= 18) {
            System.out.println("Pode votar e tirar habilitação.");
        } else if (Idade >= 16) {
            System.out.println("Pode votar, mas não tirar habilitação.");
        } else {
            System.out.println("Não pode nem votar nem tirar carteira.");
        }
    }

    static void exercicio8() {
        System.out.print("Idade do nadador: ");
        int Idade = s.nextInt();

        if (Idade >= 5 && Idade <= 7)
            System.out.println("Infantil A");
        else if (Idade <= 10)
            System.out.println("Infantil B");
        else if (Idade <= 13)
            System.out.println("Juvenil A");
        else if (Idade <= 17)
            System.out.println("Juvenil B");
        else if (Idade >= 18)
            System.out.println("Adulto");
        else
            System.out.println("Idade abaixo da categoria mínima.");
    }

    static void exercicio9() {
        int Soma = 0, n;
        do {
            System.out.print("Digite um número (0 para sair): ");
            n = s.nextInt();
            if (n % 2 == 0)
                Soma += n;
        } while (n != 0);
        System.out.println("Soma dos números pares: " + Soma);
    }

    static void exercicio10() {
        Random r = new Random();
        int num = r.nextInt(100) + 1;
        int Palpite = -1;

        while (Palpite != num) {
            System.out.print("Tente adivinhar (1 a 100): ");
            Palpite = s.nextInt();

            if (Palpite > num)
                System.out.println("Muito alto!");
            else if (Palpite < num)
                System.out.println("Muito baixo!");
            else
                System.out.println("Parabéns, você acertou!");
        }
    }

    static void exercicio11() {
        Random r = new Random();
        int n;
        do {
            System.out.print("Digite um número entre 10 e 29 (ou 9 para sair): ");
            n = s.nextInt();
            if (n == 9)
                break;
            int Sorteio = r.nextInt(20) + 10;
            if (n == Sorteio)
                System.out.println("Parabéns! Você acertou!");
            else
                System.out.println("Errou! O número sorteado foi " + Sorteio);
        } while (n != 9);
    }

    static void exercicio12() {
        System.out.print("Digite o primeiro número: ");
        int a = s.nextInt();
        System.out.print("Digite o segundo número: ");
        int b = s.nextInt();
        System.out.print("Digite o terceiro número: ");
        int c = s.nextInt();

        System.out.print("Digite 1 para ordem crescente ou 2 para decrescente: ");
        int Tipo = s.nextInt();

        int Maior = Math.max(a, Math.max(b, c));
        int Menor = Math.min(a, Math.min(b, c));
        int Meio = (a + b + c) - (Maior + Menor);

        if (Tipo == 1)
            System.out.println("Crescente: " + Menor + ", " + Meio + ", " + Maior);
        else
            System.out.println("Decrescente: " + Maior + ", " + Meio + ", " + Menor);
    }

    static void exercicio13() {
        s.nextLine();
        System.out.print("Digite uma palavra: ");
        String Palavra = s.nextLine().toLowerCase();
        int Vogais = 0, Consoantes = 0;

        for (int i = 0; i < Palavra.length(); i++) {
            char letra = Palavra.charAt(i);
            if ("aeiou".indexOf(letra) != -1)
                Vogais++;
            else if (letra >= 'a' && letra <= 'z')
                Consoantes++;
        }

        System.out.println("Vogais: " + Vogais);
        System.out.println("Consoantes: " + Consoantes);
    }

    static void exercicio14() {
        s.nextLine();
        System.out.print("Digite seu nome: ");
        String Nome = s.nextLine().toLowerCase();
        System.out.print("Digite seu sobrenome: ");
        String Sobrenome = s.nextLine().toLowerCase();
        System.out.print("Digite a senha: ");
        String Senha = s.nextLine();

        boolean Ok = true;

        if (Senha.length() < 8) Ok = false;
        if (!(Senha.contains("@") || Senha.contains("!") || Senha.contains("#"))) Ok = false;
        if (Senha.charAt(0) == Nome.charAt(0) || Senha.charAt(0) == Sobrenome.charAt(0)) Ok = false;
        if (Senha.contains(Nome) || Senha.contains(Sobrenome)) Ok = false;

        if (Ok)
            System.out.println("Senha válida!");
        else
            System.out.println("Senha inválida!");
    }

    static void exercicio15() {
        System.out.print("Digite o primeiro número: ");
        double num1 = s.nextDouble();
        System.out.print("Digite o segundo número: ");
        double num2 = s.nextDouble();

        double Resultado = Calculo(num1, num2);
        System.out.println("Resultado: " + Resultado);
    }

    static double Calculo(double num1, double num2) {
        if (num1 > num2)
            return num1 * num2;
        else if (num1 < num2)
            return num1 / num2;
        else
            return num1 + num2;
    }
}